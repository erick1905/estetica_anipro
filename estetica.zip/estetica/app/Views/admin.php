<?php echo $this->extend('Pages/plantilla'); ?>
<?php echo $this->section('contenido'); ?>


<!-- DIV para un contenido o header de presentacion -->
<div class=" container text-center">
    <img class="d-block mx-auto mb-4" src="<?= base_url('img/dow.jpg') ?>" alt="" width="326" height="182">
    <h4>BIENVENID@ A MI ESTETICA</h4>
</div>
<!-- DIV para contenido de ka app [tablas, forms, etc.] -->
</div>
<div class="container ">
    <h4> SERVICIOS A OFRECER</h4>
    <ul>
        <li>corte de pelo para caballero & dama </li>
        <li>depilacion corporal</li>
        <li>planchado de pelo</li>
        <li>peinados</li>
        <li>maquillaje</li>
        <li>manicura</li>
        <li>masaje</li>
        <img class="d-block mx-auto mb-4" src="<?= base_url('img/fondo.jpg') ?>" alt="" width="250" height="185">
    </ul>
    </style>
</div>
<?php echo $this->endSection(); ?>