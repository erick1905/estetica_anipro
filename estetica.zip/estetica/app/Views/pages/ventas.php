<?php echo $this->extend('pages/plantilla'); ?>
<?php echo $this->section('contenido'); ?>

<!-- DIV para contenido de la app [tablas, forms, etc.] -->
<div class="container  px-4  gy-5">
    <h4>Tabla ESTETICA</h4>
    <button class="btn btn-primary">VENTAS</button>
    <table class="table table-hover" id="tablacliente" name="tablacliente">
        <thead>
            <tr>
                <th scope="col">id_venta</th>
                <th scope="col">hora</th>
                <th scope="col">Fecha ingreso</th>
                <th scope="col">Fecha egreso</th>
                <th scope="col">nombre_empleado</th>


                <th scope="col">promocion</th>
            </tr>
        </thead>
        <tbody id="resultEmpleados" name="resultEmpleados">

            <!-- Aqui se cargaran las filas por medio de JS con .innerHTML-->

        </tbody>
    </table>
    <div class=" container text-center" style="display : none;" id="mensajesServer" name="mensajesServer">
    </div>
</div>
<?php echo $this->endSection(); ?>