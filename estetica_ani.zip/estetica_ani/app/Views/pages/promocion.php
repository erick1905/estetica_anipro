<?php echo $this->extend('pages/plantilla'); ?>
<?php echo $this->section('contenido'); ?>

<!-- DIV para contenido de la app [tablas, forms, etc.] -->
<div class="container  px-4  gy-5">
    <h4>Tabla ESTETICA</h4>
    <button class="btn btn-primary">PROMOCION</button>
    <table class="table table-hover" id="tablacliente" name="tablacliente">
        <thead>
            <tr>
                <th scope="col">promocion valida del 06/04/2022</th>
                <th scope="col"> la promocion termina el dia 14/05/2022</th>
                <th scope="col">aprovecha este descuentos de vacaciones</th>
                <th scope="col">descuento del 12% en cortes</th>
                <th scope="col">5% de tintes</th>
            </tr>
            <img class="d-block mx-auto mb-4" src="<?= base_url('img/606cb502aeaa08408ad11f8088368901.jpg') ?>" alt="" width="310" height="298">
        </thead>
        <tbody id="resultEmpleados" name="resultEmpleados">

            <!-- Aqui se cargaran las filas por medio de JS con .innerHTML-->

        </tbody>
    </table>
    <div class=" container text-center" style="display : none;" id="mensajesServer" name="mensajesServer">
    </div>
</div>
<?php echo $this->endSection(); ?>