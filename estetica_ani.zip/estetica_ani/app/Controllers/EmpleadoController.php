<?php

namespace App\Controllers;


use App\Models\EmpleadoModel;

/*class EmpleadoController extends BaseController
{

    //funcion para retornar undice de empleados 
    public function index()
    {

        $empleadoModel = new EmpleadoModel();

        $data['empleados'] = $empleadoModel->paginate(10);

        $data['pager'] = $empleadoModel->pager;

        return view('Pages/index', $data);
    }
}*/




// importamos los modelos que vamos a consultar

class EmpleadoController extends BaseController
{
    // vista de indice (tabla) de empleados
    public function index()
    {
        // conseguir todos los empleados vigentes de la bd
        // - creamos una instancia de la tabla de empleados
        $empleadoModel = new EmpleadoModel();

        // Recuperamos los empleados vigentes a traves del modelo
        // Como en el modelo establecimos 'fecha_egreso' como $deletedField
        // CodeIgniter sabe automaticamente que aquellos usuarios con una fecha de egreso registrada
        // son los que no estan vigentes
        // ** Armamos la consulta 
        $data['empleados'] = $empleadoModel->getAllEmpleados();
        // print_r($data['empleados']);
        // return;
        // si usamos la libreria paginate, debemos generar los links
        $data['pager'] = $empleadoModel->pager;
        // enviamos esta informacion a la vista
        // debemos crear una carpeta llama empleado dentro de app/Views
        // y dentro un archivo php llamado index.php
        return view('empleado/index', $data);
    }

    // vista de formulario para crear un nuevo empleado


    // registrar un nuevo empleado


    // vista de formulario para editar un empleado


    // actualizar los datos de un registro


    // eliminar un registro por id
    public function eliminar($id_empleado)
    {
        $empleadoModel = new EmpleadoModel(); // modelo empleado para eliminarlo de la bd
        $empleadoModel->delete($id_empleado); // eliminamos al empleado con su id
        session()->setFlashdata('success', 'El usuario fue eliminado.'); // mandamos un mensaje de éxito a la vista
        return redirect()->to(base_url('/empleados')); // redirigimos a la vista principal de empleados
    }
}
