/*
 * Esta URL debe ser la misma del servirdor.
 * Esta base_URL tiene la finalidad de tener la misma funcion de la baseURL de PHP,
 * es decir, solo hay que modificar esta URL cuando se cambia de servidor
 */
var base_URL = "http://localhost/estetica_ani/public/";
